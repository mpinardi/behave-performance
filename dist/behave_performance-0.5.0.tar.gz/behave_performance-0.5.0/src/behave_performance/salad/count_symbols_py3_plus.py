def count_symbols(string):
    return len(string)
