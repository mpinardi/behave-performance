# Behave-Performance

## Build
  You can build with setup.py
  >  python setup.py sdist bdist_wheel

## Test
  You can run unit tests using pytest
  >  pytest

## Install
  You can install with pip